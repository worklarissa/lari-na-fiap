CREATE TABLE T_FIAP_PRODUTO(
    codigo int,
    tipo VARCHAR(50),
    marca VARCHAR(30),
    valor number(9,2)
);

DROP TABLE PRODUTO;
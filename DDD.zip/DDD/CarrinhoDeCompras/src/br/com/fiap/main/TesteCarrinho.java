package br.com.fiap.main;

import javax.swing.JOptionPane;

public class TesteCarrinho {

	//String
	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}
	
	//int
	static int inteiro(String ) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	
	//double
	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j))
	}
	
	
	public static void main(String[] args) {
		//instanciar objetos
		Produto[] vetorProdutos = new Produto[3];
		
		//o indice controla as posições das entradas de cada produto no vetor
		int indice =0;
		
		//começa a executar as entradas
		do {
			vetorProdutos[indice] = new Produto();
			vetorProdutos[indice].setCodigo(inteiro("Informe o código"));
			vetorProdutos[indice].setTipo(texto("Informe o tipo"));
			vetorProdutos[indice].setMarca(texto("Informe a marca"));
			vetorProdutos[indice].setQuantidade(inteiro("Informe a quantidade"));
			vetorProdutos[indice].setPreco(real("Informe o preço"));
			
		}while(JOptionPane.showConfirmDialog(null,"Adicionar mais produtos?",
				"CARRINHO DE COMPRAS", JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE> ==0));
		

	}
	
	

}

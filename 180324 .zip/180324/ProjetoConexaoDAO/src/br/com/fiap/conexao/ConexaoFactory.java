package br.com.fiap.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoFactory {
	
	//metodo conexao
	public Connection conexao() throws ClassNotFoundException, SQLException{
		
		//Driver
		Class.forName("oracle.jdbc.driver.OrcleDriver");
		
		//Conexao
		return DriverManager.getConnection("jdbc:oracle:thin:@oracle.com.br.fiap:1521:orcl", "RM552628", "080704");
	}

}

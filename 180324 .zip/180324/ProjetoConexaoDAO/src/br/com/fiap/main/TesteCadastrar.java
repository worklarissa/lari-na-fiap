package br.com.fiap.main;

import br.com.fiap.beans.Produto;

public class TesteCadastrar {

	public static void main(String[] args) {
		
		Produto objProduto = new Produto();
		
		ProdutoDAO dao = new ProdutoDAO();
		
		objProduto.setCodigo("Codigo");
		objProduto.setTipo("Codigo");
		objProduto.setMarca("Codigo");
		objProduto.setValor("Codigo");
		
		System.out.println();
		
	}

}

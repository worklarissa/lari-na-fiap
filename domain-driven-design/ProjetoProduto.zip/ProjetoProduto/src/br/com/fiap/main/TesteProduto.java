package br.com.fiap.main;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Cliente;
import br.com.fiap.beans.Colaborador;
import br.com.fiap.beans.Endereco;

public class TesteProduto {

	public static void main(String[] args) {
		
		
		Cliente objCliente = new Cliente();
		Colaborador objColaborador = new Colaborador();
		Endereco objEndereco = new Endereco ();
		
		
		//Entradas
		//Cliente
		objCliente.setNome(JOptionPane.showInputDialog("Digite o nome do cliente"));
		objCliente.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Digite sua idade")));
		
		//Endereço
		objEndereco.setLogradouro(JOptionPane.showInputDialog("Informe o logradouro"));
		objEndereco.setNumero(Integer.parseInt(JOptionPane.showInputDialog("Digite o numero")));
		
		//Colaborador
		objColaborador.setNome(JOptionPane.showInputDialog("Digite o nome do colaborador"));
		objColaborador.setSalario(Double.parseDouble(JOptionPane.showInputDialog("Digite o salario")));

		//Saidas
		System.out.println("INFORMACOES CLIENTE" +
		"\nNome: " + objCliente.getNome() +
		"\nIdade: " + objCliente.getIdade() +
		"\n\nINFORMACOES ENDERECO" + 
		"\nLogradouro: " + objEndereco.getLogradouro() +
		"\nNumero: " + objEndereco.getNumero() +
		"\n\nINFORMACOES DO COLABORADOR" +
		objColaborador.getTudo());
		
		
		System.out.println ("\n\nTAXA: \n" + objColaborador.pagaTaxa());

	}

}
